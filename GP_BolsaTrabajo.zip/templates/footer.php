<!-- <footer class="main-footer text-sm">

  <div class="float-right d-none d-sm-inline">
    2023
  </div>

  <strong><a href="#">Presidencia Goméz Palacio</a></strong>.
</footer> -->

<!-- </div> -->



<!-- SCRIPTS -->
<!-- POPPER JS -->
<script src="<?=$PLUGINS_PATH?>/popper/popper.min.js"></script>

<!-- BOOTSTRAP 5.3 -->
<!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script> -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js"></script>

<!-- ADMINLTE 3.2 -->
<!-- <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2.0/dist/js/adminlte.min.js"></script> -->
<script src="<?=$ADMINLTE_PATH?>/js/adminlte.min.js"></script>

<!-- JQUERY -->
<script src="/plugins/jquery-validation/jquery.numeric.js"></script>
<!-- <script src="<? /* =$PLUGINS_PATH */?>/jquery-validation/jquery.validate.min.js"></script>
  <script src="<? /* =$PLUGINS_PATH */?>/jquery-validation/additional-methods.min.js"></script> -->

<!-- DataTables -->
<script type="text/javascript" src="<?=$PLUGINS_PATH?>/dataTables/js/pdfmake.min.js"></script>
<script type="text/javascript" src="<?=$PLUGINS_PATH?>/dataTables/js/vfs_fonts.js"></script>
<script type="text/javascript"
  src="<?=$PLUGINS_PATH?>/dataTables/js/datatables.min.js">
</script>
<script type="text/javascript" src="<?=$PLUGINS_PATH?>/dataTables/js/dataTables.buttons.min.js"></script>
<script type="text/javascript" src="<?=$PLUGINS_PATH?>/dataTables/js/jszip.min.js"></script>
<script type="text/javascript" src="<?=$PLUGINS_PATH?>/dataTables/js/buttons.html5.min.js"></script>

<!-- Moment JS -->
<script src="<?=$PLUGINS_PATH?>/moment-js/moment.min.js"></script>
<script src="<?=$PLUGINS_PATH?>/moment-js/es-mx.js"></script>

<!-- SweetAlert2 -->
<script src="<?=$PLUGINS_PATH?>/sweetAlert2/js/sweetalert2.all.min.js"></script>

<!-- Select2 -->
<script src="<?=$PLUGINS_PATH?>/select2/js/select2.min.js"></script>

<!-- Ion-RangeSlider -->
<link rel="stylesheet" href="<?=$PLUGINS_PATH?>/ion-rangeslider/js/ion.rangeSlider.min.js">
<!-- BootstrapSlider -->
<!-- <link rel="stylesheet" href="<?=$PLUGINS_PATH?>/bootstrap-slider/js/bootstrap-slider.min.js"> -->


<!-- Block-UI -->
<script src="<?=$PLUGINS_PATH?>/BlockUI/jquery.blockui.min.js"></script>

<!-- Cookies -->
<script src="<?=$PLUGINS_PATH?>/js-cookie/js.cookie.min.js"></script>

<!-- SUMMERNOTE - EDITOR DE TEXTO -->
<script src="/plugins/summernote-0.8.18/summernote.min.js"></script>
<script src="/plugins/summernote-0.8.18/summernote-bs4.min.js"></script>
<script src="/plugins/summernote-0.8.18/lang/summernote-es-ES.min.js"></script>

<!-- bs-stepper- formularios en pasos -->
<!-- <script src="https://cdn.jsdelivr.net/npm/bs-stepper/dist/js/bs-stepper.min.js" charset="utf-8"></script> -->

<!-- IMask JS -->
<!-- <script src="<?=$PLUGINS_PATH?>/imask-js/imask.js"></script> -->

<script src="<?=$SCRIPTS_PATH?>/master.js"></script>
